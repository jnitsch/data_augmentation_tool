#!/usr/bin/python

"""
loads hdf5 caffe file and shows one single image of each label
"""
__author__ = 'Julia Nitsch'
import argparse

import data_augmentation_tool.io as io

def main():
    parser = argparse.ArgumentParser(description='''

    ''')
    parser.add_argument('--filename', help='path+filename of hdf5 file', default='')
    args = parser.parse_args()
    filename = args.filename


    label = io.load_hdf5_labels(filename)
    img = io.load_hdf5_img(filename)

    print 'test'
    if img.shape[1] is 1:
        print 'Images are grayscale'

    if img.shape[1] is 3:
        print 'Images are colorized'


if __name__ == "__main__":
    main()